INSERT OR REPLACE INTO LocalizedText
  (Tag,	Language,	Text)
VALUES
  ('LOC_UI_MINI_MAP_MISSIONARY',		'en_US',	"Missionary"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'ru_RU',	"Миссионеры"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'de_DE',	"Missionar"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'es_ES',	"Misionero"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'fr_FR',	"Missionnaire"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'it_IT',	"Missionario"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'ja_JP',	"宣教師"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'ko_KR',	"전도사"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'pl_PL',	"Misjonarz"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'pt_BR',	"Missionário"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'zh_Hans_CN',	"传教士"),
  ('LOC_UI_MINI_MAP_MISSIONARY',		'zh_Hant_HK',	"傳道者");
