/**
 * Huge shoutout to @realitymeltdown in the official Civ VII Discord for figuring this out.
 */
export class AmlPanelMiniMapDecorator {
    constructor(val) {
        this.miniMap = val;
    }

    beforeAttach() {
    }

    afterAttach() {
        this.miniMap.createLensButton("LOC_UI_MINI_MAP_MISSIONARY", "aml-missionary-lens", "lens-group");
    }

    beforeDetach() { }

    afterDetach() { }

    onAttributeChanged(name, prev, next) { }
}

Controls.decorate('lens-panel', (val) => new AmlPanelMiniMapDecorator(val));
