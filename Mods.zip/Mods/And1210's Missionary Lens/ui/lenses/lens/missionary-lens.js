/**
 * @file religion-lens.ts
 * @description Lens shown when a religion unit is selected
 */
import LensManager from '/core/ui/lenses/lens-manager.js';
class MissionaryLens {
    constructor() {
        this.activeLayers = new Set([
          'fxs-hexgrid-layer',
          'fxs-culture-borders-layer',
          'aml-missionary-layer',
          'aml-city-boundary-layer',
          'aml-missionaries-layer'
        ]);
        this.allowedLayers = new Set([
          'fxs-resource-layer'
        ]);
    }
}
LensManager.registerLens('aml-missionary-lens', new MissionaryLens());

//# sourceMappingURL=file:///base-standard/ui/lenses/lens/religion-lens.js.map
