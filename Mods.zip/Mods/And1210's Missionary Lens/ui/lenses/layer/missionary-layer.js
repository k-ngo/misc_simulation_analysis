/**
 * @file resource-layer
 * @description Lens layer to show religion on the map
 */
import LensManager from '/core/ui/lenses/lens-manager.js';
import PlotIconsManager from '/core/ui/plot-icons/plot-icons-manager.js';

class MissionaryLensLayer {
    constructor() {
        this.cityReligionRuralUpdateListener = (data) => {this.onCityRuralReligionUpdate(data);}
        this.cityReligionUrbanUpdateListener = (data) => {this.onCityUrbanReligionUpdate(data);}
        this.ruralReligionMap = new Map();
        this.urbanReligionMap = new Map();

        this.onLayerHotkeyListener = this.onLayerHotkey.bind(this);
        this.isApplied = false;
    }
    updateXY(x, y) {
      const cityID = GameplayMap.getOwningCityFromXY(x, y);
      if (cityID != null) {
        const city = Cities.get(cityID);
        if (city != null) {
          const cityReligion = city.Religion;
          if (cityReligion != null) {
            const plotIndex = GameplayMap.getIndexFromLocation({x: x, y: y});
            const district = Districts.getAtLocation(plotIndex);
            if (district) {
              const districtTypeName = GameInfo.Districts.lookup(district.type).Name;
              // console.warn(districtDefinition.Name);
              const ruralReligion = GameInfo.Religions.find(t => t.$hash == cityReligion.ruralReligion);
              const urbanReligion = GameInfo.Religions.find(t => t.$hash == cityReligion.urbanReligion);
              if (districtTypeName == 'LOC_DISTRICT_RURAL_NAME' && ruralReligion) {
                const key = this.makeKey(x, y);
                this.ruralReligionMap.set(key, {location: {x: x, y: y}, religion: ruralReligion.ReligionType});
              }
              if ((districtTypeName == 'LOC_DISTRICT_URBAN_NAME' || districtTypeName == 'LOC_DISTRICT_CITY_CENTER_NAME') && urbanReligion) {
                const key = this.makeKey(x, y);
                this.urbanReligionMap.set(key, {location: {x: x, y: y}, religion: urbanReligion.ReligionType});
              }
            }
          }
        }
      }
    }
    initLayer() {
        const nT = (n) => {
          let out = "";
          for (let i = 0; i < n; i++) {
            out += '\t';
          }
          return out;
        }
        const displayJSON = (d, i) => {
          for (let k in d) {
            if (typeof d[k] != typeof {}) {
              console.warn(`${nT(i)}${k}: "${d[k]}",`);
            } else {
              console.warn(`${nT(i)}${k}: {`);
              displayJSON(d[k], i+1);
              console.warn(`${nT(i)}},`);
            }
            // if (i == 0) {
            //   console.warn('----------------------------------------------------------------');
            // }
          }
        };

        engine.on('RuralReligionChanged', this.cityReligionRuralUpdateListener);
        engine.on('UrbanReligionChanged', this.cityReligionUrbanUpdateListener);
        const width = GameplayMap.getGridWidth();
        const height = GameplayMap.getGridHeight();
        for (let x = 0; x < width; x++) {
            for (let y = 0; y < height; y++) {
              this.updateXY(x, y);
            }
        }
        // window.addEventListener('layer-hotkey', this.onLayerHotkeyListener);
    }
    applyLayer() {
        if (!this.isApplied) {
            this.isApplied = true;
            this.ruralReligionMap.forEach((entry) => {
                PlotIconsManager.addPlotIcon('plot-icon-religion', entry.location, new Map([['religion', entry.religion]]));
            });
            this.urbanReligionMap.forEach((entry) => {
                PlotIconsManager.addPlotIcon('plot-icon-religion', entry.location, new Map([['religion', entry.religion]]));
            });
        }
    }
    removeLayer() {
        if (this.isApplied) {
            this.isApplied = false;
            PlotIconsManager.removePlotIcons('plot-icon-religion');
        }
    }
    makeKey(x, y) {
        return `${x},${y}`;
    }
    onCityRuralReligionUpdate(data) {
      const city = Cities.get(data.cityID);
      // const religionHash = data.newReligion;
      const width = GameplayMap.getGridWidth();
      const height = GameplayMap.getGridHeight();
      for (let i = -3; i < 4; i++) {
        for (let j = -3; j < 4; j++) {
          let x = city.location.x + i;
          if (x < 0) {x += width;}
          if (x > width) {x = x % width;}
          let y = city.location.y + j;
          if (y < 0) {y += height;}
          if (y > height) {y = y % height;}

          this.updateXY(x, y);
        }
      }
    }
    onCityUrbanReligionUpdate(data) {
      const city = Cities.get(data.cityID);
      // const religionHash = data.newReligion;
      const width = GameplayMap.getGridWidth();
      const height = GameplayMap.getGridHeight();
      for (let i = -3; i < 4; i++) {
        for (let j = -3; j < 4; j++) {
          let x = city.location.x + i;
          if (x < 0) {x += width;}
          if (x > width) {x = x % width;}
          let y = city.location.y + j;
          if (y < 0) {y += height;}
          if (y > height) {y = y % height;}

          this.updateXY(x, y);
        }
      }
    }
    onLayerHotkey(hotkey) {
        // if (hotkey.detail.name == 'toggle-resources-layer') {
        //     LensManager.toggleLayer('fxs-resource-layer');
        // }
    }
}

LensManager.registerLensLayer('aml-missionary-layer', new MissionaryLensLayer());

//# sourceMappingURL=file:///base-standard/ui/lenses/layer/religion-layer.js.map
