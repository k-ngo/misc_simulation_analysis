/**
 * @file resource-layer
 * @description Lens layer to show where missionaries are on the map
 */
import LensManager from '/core/ui/lenses/lens-manager.js';
import PlotIconsManager from '/core/ui/plot-icons/plot-icons-manager.js';

class MissionariesLensLayer {
    constructor() {
        this.missionariesOverlayGroup = WorldUI.createOverlayGroup("MissionariesOverlayGroup", 2);
        this.missionariesOverlay = this.missionariesOverlayGroup.addPlotOverlay();
        this.missionariesLocs = [];
        // this.missionariesColour = {x: 0, g: 0, b: 1, w: 0.8};
        this.missionariesColour = {x: 1, y: 1, z: 1, w: 1};

        this.onUnitMovedListener = (data) => {this.onUnitMoved(data)};

        this.onLayerHotkeyListener = this.onLayerHotkey.bind(this);
    }
    clearOverlay() {
        this.missionariesOverlayGroup.clearAll();
        this.missionariesOverlay.clear();

        this.missionariesLocs = [];
    }
    initLayer() {
        const nT = (n) => {
          let out = "";
          for (let i = 0; i < n; i++) {
            out += '\t';
          }
          return out;
        }
        const displayJSON = (d, i) => {
          for (let k in d) {
            if (typeof d[k] != typeof {}) {
              console.warn(`${nT(i)}${k}: "${d[k]}",`);
            } else {
              console.warn(`${nT(i)}${k}: {`);
              displayJSON(d[k], i+1);
              console.warn(`${nT(i)}},`);
            }
            // if (i == 0) {
            //   console.warn('----------------------------------------------------------------');
            // }
          }
        };

        engine.on('UnitMoved', this.onUnitMovedListener);

        // window.addEventListener('layer-hotkey', this.onLayerHotkeyListener);
    }
    applyLayer() {
      this.missionariesLocs = [];
      const allPlayers = Players.getAlive();
      if (allPlayers) {
        for (let player of allPlayers) {
          const playerUnits = player.Units;
          if (playerUnits) {
            for (const unit of playerUnits.getUnits()) {
              const unitDef = GameInfo.Units.lookup(unit.type);
              if (unitDef) {
                if (unitDef.UnitType == "UNIT_MISSIONARY" || unitDef.UnitType == "UNIT_HOCEEPKILENI" || unitDef.UnitType == "UNIT_KAHUNA" || unitDef.UnitType == "UNIT_PEDANDA") {
                  const loc = {x: unit.location.x, y: unit.location.y};
                  const isVisible = GameplayMap.getRevealedState(GameContext.localPlayerID, loc.x, loc.y) == RevealedStates.VISIBLE;
                  if (isVisible == true) {
                    this.missionariesLocs.push(loc);
                  }
                }
              }
            }
          }
        }
      }
      this.missionariesOverlay.addPlots(this.missionariesLocs, {fillColor: this.missionariesColour});
    }
    removeLayer() {
      this.clearOverlay();
    }
    makeKey(x, y) {
        return `${x},${y}`;
    }
    onUnitMoved(data) {
      // data:
        // destinationVisibleToLocalPlayer,visibleToLocalPlayer,toStateChange,location,parent,unit

      // console.warn('Unit Moved');
      // // console.warn(Object.keys(data.unit.id));
      // console.warn(`${data.location.x}, ${data.location.y}`);
      // // console.warn(data.unit.id); //id, owner, type
      // const unit = Units.get(data.unit.id);
      // console.warn(unit);
      // console.warn(Object.keys(unit));
      // console.warn(`${unit.location.x}, ${unit.location.y}`);
      // const unitDef = GameInfo.Units.lookup(unit.type);
    }
    onLayerHotkey(hotkey) {
    }
}

LensManager.registerLensLayer('aml-missionaries-layer', new MissionariesLensLayer());

//# sourceMappingURL=file:///base-standard/ui/lenses/layer/religion-layer.js.map
