/**
 * @file resource-layer
 * @description Lens layer to show individual cities on the map
 */
import LensManager from '/core/ui/lenses/lens-manager.js';

class CityBoundaryLensLayer {
    constructor() {
        this.cityBoundaryOverlayGroup = WorldUI.createOverlayGroup("CityBoundaryOverlayGroup", 1);
        this.cityBoundaryOverlay = this.cityBoundaryOverlayGroup.addPlotOverlay();

        this.city_data = {};
    }
    clearOverlay() {
        this.cityBoundaryOverlayGroup.clearAll();
        this.cityBoundaryOverlay.clear();

        this.city_data = {};
    }
    idToColour(id, alpha) {
      let r=0, g=0, b=0;
      const val = (""+id);
      const len = val.length;
      if (len >= 6) {
        r = parseFloat(val.substring(len-6, len-4));
        g = parseFloat(val.substring(len-4, len-2));
        b = parseFloat(val.substring(len-2, len));
      } else if (len >= 2) {
        r = parseFloat(val.substring(len-2, len));
        g = parseFloat(val.substring(len-2, len));
        b = parseFloat(val.substring(len-2, len));
      } else {

      }

      return { x: r / 99, y: g / 99, z: b / 99, w: Math.min(1, Math.max(0, alpha)) };
    }
    updateXY(x, y) {
      const cityID = GameplayMap.getOwningCityFromXY(x, y);
      if (cityID != null) {
        if (!(cityID.id in this.city_data)) {
          this.city_data[cityID.id] = {
            colour: this.idToColour(cityID.id, 0.6),
            locs: [{x, y}]
          };
        } else {
          this.city_data[cityID.id].locs.push({x, y});
        }
      }
    }
    initLayer() {
    }
    applyLayer() {
        this.clearOverlay();
        const width = GameplayMap.getGridWidth();
        const height = GameplayMap.getGridHeight();
        for (let x = 0; x < width; x++) {
            for (let y = 0; y < height; y++) {
              this.updateXY(x, y);
            }
        }

        for (let id in this.city_data) {
          this.cityBoundaryOverlay.addPlots(this.city_data[id].locs, {fillColor: this.city_data[id].colour});
        }
    }
    removeLayer() {
        this.clearOverlay();
    }
}

LensManager.registerLensLayer('aml-city-boundary-layer', new CityBoundaryLensLayer());

//# sourceMappingURL=file:///base-standard/ui/lenses/layer/religion-layer.js.map
