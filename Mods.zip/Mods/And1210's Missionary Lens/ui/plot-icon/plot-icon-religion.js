/**
 * @file Resource Plot Icon
 * @copyright 2021-2024, Firaxis Games
 * @description Icon to show the religion on this plot
 */
import { FxsIcon } from '/core/ui/components/fxs-icon.js';
class PlotIconReligion extends FxsIcon {
    constructor() {
        super(...arguments);
        this.location = { x: -1, y: -1 };
    }
    onInitialize() {
        super.onInitialize();
        this.Root.classList.add("size-8", "bg-contain", "bg-no-repeat", "-translate-y-1\\/2");
        this.location = {
            x: parseInt(this.Root.getAttribute('x') ?? '-1'),
            y: parseInt(this.Root.getAttribute('y') ?? '-1'),
        };
        const religionType = this.Root.getAttribute("religion");
        if (religionType) {
            const revealedState = GameplayMap.getRevealedState(GameContext.localPlayerID, this.location.x, this.location.y);
            this.Root.setAttribute("data-icon-id", religionType);
            this.Root.setAttribute("data-icon-context", (revealedState == RevealedStates.REVEALED) ? "RELIGION_FOW" : "RELIGION");
        }
        else {
            console.error(`Cannot make religion icon. No resource attribute defined. ${this.location.x}, ${this.location.y}`);
            return;
        }
    }
}
Controls.define('plot-icon-religion', {
    createInstance: PlotIconReligion,
    description: 'Religion Plot Icon',
    classNames: ['religion-icon-img']
});

//# sourceMappingURL=file:///base-standard/ui/plot-icon/plot-icon-resource.js.map
