/**
 * @file screen-pause-menu.ts
 * @copyright 2020-2022, Firaxis Games
 * @description In-game pause menu; should always be assessible.
 */
import { getPlayerCardInfo } from '/core/ui/utilities/utilities-liveops.js';
import { LowerCalloutEvent } from '/base-standard/ui/tutorial/tutorial-events.js';
import ContextManager from '/core/ui/context-manager/context-manager.js';
import { DisplayQueueManager } from '/core/ui/context-manager/display-queue-manager.js';
import DialogManager, { DialogBoxAction, DialogSource } from '/core/ui/dialog-box/manager-dialog-box.js';
import { InputEngineEventName } from '/core/ui/input/input-support.js';
import NavTray from '/core/ui/navigation-tray/model-navigation-tray.js';
import Panel from '/core/ui/panel-support.js';
import SaveLoadData from '/core/ui/save-load/model-save-load.js';
import { Icon } from '/core/ui/utilities/utilities-image.js';
import { NetworkUtilities } from 'core/ui/utilities/utilities-network.js';
import { displayRequestUniqueId } from '/core/ui/context-manager/display-handler.js';
import { Focus } from '/core/ui/input/focus-support.js';
var Group;
(function (Group) {
    Group[Group["PrimaryHeader"] = 0] = "PrimaryHeader";
    Group[Group["SecondaryHeader"] = 1] = "SecondaryHeader";
    Group[Group["Primary"] = 2] = "Primary";
    Group[Group["Secondary"] = 3] = "Secondary";
    Group[Group["PrimaryFooter"] = 4] = "PrimaryFooter";
    Group[Group["SecondaryFooter"] = 5] = "SecondaryFooter";
})(Group || (Group = {}));
/**
 * Pause menu based on screen-tech-tree-chooser.ts
 */
export class ScreenPauseMenu extends Panel {
    constructor(root) {
        super(root);
        this.engineInputListener = this.onEngineInput.bind(this);
        this.closeButtonListener = () => { this.close(); };
        this.buttonListener = (_e) => { }; // Use for callbacks; needed here for scope reasons even though it's overwritten.
        this.progressionListener = this.onClickedProgression.bind(this);
        this.slot = null;
        this.quickSaveButton = null;
        this.saveButton = null;
        this.loadButton = null;
        this.buttons = new Set();
        this.showMoreElement = null;
        this.dialogId = displayRequestUniqueId();
        this.animateInType = this.animateOutType = 7 /* AnchorType.RelativeToRight */;
        this.enableOpenSound = true;
        this.enableCloseSound = true;
        this.Root.setAttribute("data-audio-group-ref", "pause-menu");
    }
    onAttach() {
        super.onAttach();
        engine.on('LocalPlayerTurnBegin', this.onLocalPlayerTurnBegin, this);
        engine.on('LocalPlayerTurnEnd', this.onLocalPlayerTurnEnd, this);
        engine.on('StartSaveRequest', this.onStartSaveRequest, this);
        engine.on("SaveComplete", this.onSaveComplete, this);
        if (!Configuration.getGame().isNetworkMultiplayer) {
            const progressionContainer = this.Root.querySelector(".pause-menu__progression-container");
            progressionContainer.style.display = "none";
        }
        else { // Run original code to not potentially break things
            const playerHeader = this.Root.querySelector(".pause-menu__player-info");
            if (playerHeader) {
                if (Network.supportsSSO()) {
                    const playerInfo = getPlayerCardInfo();
                    playerHeader.setAttribute("data-player-info", JSON.stringify(playerInfo));
                    playerHeader.addEventListener("action-activate", this.progressionListener);
                }
                else {
                    playerHeader.style.display = "none";
                }
            }
        }

        // Quick Save
        this.quickSaveButton = this.addButton("LOC_PAUSE_MENU_QUICK_SAVE", this.onQuickSaveGameButton, Group.PrimaryHeader);

        // Event Rules
        if (Online.Metaprogression.isPlayingActiveEvent()) {
            this.addButton("LOC_PAUSE_MENU_EVENT_RULES", this.onEventRules, Group.Primary);
        }

        // Save & Load
        this.saveButton = this.addButton("LOC_PAUSE_MENU_SAVE", this.onSaveGameButton, Group.Primary, "none");
        if (!Configuration.getGame().isNetworkMultiplayer) {
            this.loadButton = this.addButton("LOC_PAUSE_MENU_LOAD", this.onLoadGameButton, Group.Primary, "none");
        }

        // Progression
        if (Network.isMetagamingAvailable() && !Configuration.getGame().isNetworkMultiplayer) {
            this.addButton("LOC_PROFILE_TAB_PROGRESS", this.onClickedProgression, Group.Primary);
        }

        // Challenges
        if (Network.isMetagamingAvailable()) {
            this.addButton("LOC_PROFILE_TAB_CHALLENGES", this.onChallenges, Group.Primary);
        }

        // Options
        this.addButton("LOC_PAUSE_MENU_OPTIONS", this.onOptionsButton, Group.Primary, "data-audio-options-activate");

        // Social
        if (Network.supportsSSO() && Network.isFullAccountLinked()) {
            this.addButton("LOC_UI_SOCIAL_TITLE", this.onSocialButton, Group.Primary, "data-audio-social-activate");
        }

        // Retire
        const victoryManager = Game.VictoryManager;
        const playerDefeated = victoryManager.getLatestPlayerDefeat(GameContext.localPlayerID) != DefeatTypes.NO_DEFEAT;
        // If the age is over and/or you've been defeated, replace the 'retire' button with 'No More Turns' button since
        // you likely got here by clicking 'Just One More Turn'.
        if (Game.AgeProgressManager.isAgeOver || playerDefeated) {
            this.addButton("LOC_PAUSE_MENU_NOMORETURNS", this.onNoMoreTurnsButton, Group.Primary);
        }
        else if (!Configuration.getGame().isNetworkMultiplayer) {
            const retireButton = this.addButton("LOC_PAUSE_MENU_RETIRE", this.onRetireButton, Group.Primary);
            const player = Players.get(GameContext.localPlayerID);
            retireButton.classList.add("pause-retire-button");
            if (player && !player.isTurnActive) {
                this.updateRetireButton(retireButton, false);
            }
        }

        // Quit to Main Menu
        this.addButton("LOC_PAUSE_MENU_QUIT_TO_MENU", this.onExitToMainMenuButton, Group.PrimaryFooter);
        if (Configuration.getGame().isAnyMultiplayer) {
            // this.addButton(Locale.compose("LOC_PAUSE_MENU_COPY_JOIN_CODE", Network.getJoinCode()), this.onJoinCodeButton, Group.Secondary);
            this.addButton(Locale.compose("LOC_PAUSE_MENU_COPY_JOIN_CODE", Network.getJoinCode()), this.onJoinCodeButton, Group.Primary);
        }

        // Quit to Desktop
        if (UI.canExitToDesktop()) {
            this.addButton("LOC_PAUSE_MENU_QUIT_TO_DESKTOP", this.onExitToDesktopButton, Group.PrimaryFooter);
        }

        this.Root.addEventListener(InputEngineEventName, this.engineInputListener);
        this.slot = this.Root.querySelector(".pauselist");
        const bg = document.getElementById("pause-top");
        if (bg) {
            bg.setAttribute("headerimage", Icon.getPlayerBackgroundImage(GameContext.localPlayerID));
        }
        const gameInfo = this.Root.querySelector(".pause-menu__game-info");
        if (gameInfo) {
            const { startAgeType, difficultyType, gameSpeedType } = Configuration.getGame();
            const ageName = GameInfo.Ages.lookup(startAgeType)?.Name;
            const difficultyName = GameInfo.Difficulties.lookup(difficultyType)?.Name;
            const gameSpeedName = GameInfo.GameSpeeds.lookup(gameSpeedType)?.Name;
            const turnCountKey = (Game.maxTurns > 0) ? 'LOC_ACTION_PANEL_CURRENT_TURN_OVER_MAX_TURNS' : 'LOC_ACTION_PANEL_CURRENT_TURN';
            const turnCount = Locale.compose(turnCountKey, Game.turn, Game.maxTurns);
            const details = [turnCount];
            if (ageName) {
                details.push(Locale.compose(ageName));
            }
            if (gameSpeedName) {
                details.push(Locale.compose(gameSpeedName));
            }
            if (difficultyName) {
                details.push(Locale.compose(difficultyName));
            }
            gameInfo.textContent = details.join(" | ");
        }
        const gameInfoMapSeed = this.Root.querySelector(".pause-menu__game-info-map-seed");
        if (gameInfoMapSeed) {
            /// get the map seed
            const seed = Configuration.getMap().mapSeed;
            const mapSeed = seed.toString();
            const mapSeedText = Locale.compose("LOC_MAPSEED_NAME") + " " + Locale.compose(mapSeed);
            if (mapSeedText) {
                gameInfoMapSeed.textContent = mapSeedText;
            }
        }
        this.realizeBuildInfoString();
        window.dispatchEvent(new LowerCalloutEvent({ closed: false }));
        // if the cursor is locked, unlock it now so we aren't navigating with a non-pointer cursor
        if (UI.isCursorLocked()) {
            UI.lockCursor(false);
        }
        // let the dialog box manager know we want to display shell dialog box only
        DialogManager.setSource(DialogSource.Shell);
        waitForLayout(() => {
            this.syncronizeButtonWidths();
        });
        Telemetry.sendUIMenuAction({ Menu: TelemetryMenuType.PauseMenu, MenuAction: TelemetryMenuActionType.Load });
    }
    onDetach() {
        Telemetry.sendUIMenuAction({ Menu: TelemetryMenuType.PauseMenu, MenuAction: TelemetryMenuActionType.Exit });
        this.Root.removeEventListener(InputEngineEventName, this.engineInputListener);
        engine.off('LocalPlayerTurnBegin', this.onLocalPlayerTurnBegin, this);
        engine.off('LocalPlayerTurnEnd', this.onLocalPlayerTurnEnd, this);
        engine.off('StartSaveRequest', this.onStartSaveRequest, this);
        engine.off("SaveComplete", this.onSaveComplete, this);
        super.onDetach();
    }
    onReceiveFocus() {
        super.onReceiveFocus();
        NavTray.clear();
        NavTray.addOrUpdateGenericBack();
        if (this.slot) {
            Focus.setContextAwareFocus(this.slot, this.Root);
        }
    }
    onLoseFocus() {
        NavTray.clear();
        super.onLoseFocus();
    }
    close() {
        DialogManager.setSource(DialogSource.Game);
        DisplayQueueManager.resume();
        super.close();
    }
    onClickedProgression() {
        ContextManager.push("screen-profile-page", { singleton: true, createMouseGuard: true, panelOptions: { onlyChallenges: false, onlyLeaderboards: false, noCustomize: true } });
    }
    onLocalPlayerTurnBegin() {
        const retireButton = this.Root.querySelector(".pause-retire-button");
        if (retireButton) {
            this.updateRetireButton(retireButton, true);
        }
    }
    onLocalPlayerTurnEnd() {
        const retireButton = this.Root.querySelector(".pause-retire-button");
        if (retireButton) {
            this.updateRetireButton(retireButton, false);
        }
    }
    onStartSaveRequest() {
        this.quickSaveButton?.classList.add("disabled");
        this.saveButton?.classList.add("disabled");
        this.loadButton?.classList.add("disabled");
    }
    onSaveComplete() {
        this.quickSaveButton?.classList.remove("disabled");
        this.saveButton?.classList.remove("disabled");
        this.loadButton?.classList.remove("disabled");
    }
    updateRetireButton(retireButton, turnActive) {
        retireButton.classList.toggle("disabled", !turnActive);
        if (!turnActive) {
            retireButton.setAttribute("data-tooltip-content", "LOC_PAUSE_MENU_RETIRE_DISABLED");
        }
        else {
            retireButton.removeAttribute("data-tooltip-content");
        }
    }
    onEngineInput(inputEvent) {
        if (inputEvent.detail.status != InputActionStatuses.FINISH) {
            return;
        }
        if (inputEvent.detail.name == "shell-action-5") {
            inputEvent.stopPropagation();
            inputEvent.preventDefault();
            ContextManager.push("screen-profile-page", { singleton: true, createMouseGuard: true, panelOptions: { onlyChallenges: false, onlyLeaderboards: false, noCustomize: true } });
        }
        if (inputEvent.isCancelInput() || inputEvent.detail.name == 'sys-menu') {
            inputEvent.stopPropagation();
            inputEvent.preventDefault();
            this.close();
            this.Root.removeEventListener(InputEngineEventName, this.engineInputListener);
        }
    }
    getGroupRoot(group) {
        let selector = '.pause-menu__main-buttons>.pauselist';
        switch (group) {
            case Group.PrimaryHeader:
                selector = '.pause-menu__header-buttons>.pauselist';
                break;
            case Group.SecondaryHeader:
                selector = '.pause-menu__header-buttons>.morelist';
                break;
            case Group.Secondary:
                selector = '.pause-menu__main-buttons>.morelist';
                break;
            case Group.PrimaryFooter:
                selector = '.pause-menu__footer-buttons>.pauselist';
                break;
            case Group.SecondaryFooter:
                selector = '.pause-menu__footer-buttons>.morelist';
                break;
        }
        return this.Root.querySelector(selector);
    }
    /**
     * Add a button to the list
     * @param caption Localization key for the button caption.
     * @param buttonListener Function to activate when button is selected
     * @param group Which group to place the button in.
     * @param activateSound activate sound to play when button is released
     * @returns DOM element for the button.
     */
    addButton(caption, buttonListener, group, activateSound = "data-audio-pause-menu-activate") {
        const target = this.getGroupRoot(group);
        const button = document.createElement('fxs-button');
        {
            button.classList.add('pause-menu-button', 'mb-1\\.5');
            button.setAttribute('caption', Locale.compose(caption));
            button.setAttribute("data-audio-group-ref", "pause-menu");
            button.setAttribute("data-audio-focus-ref", "data-audio-pause-menu-focus");
            button.setAttribute("data-audio-activate-ref", activateSound);
            // join button has already localized text in caption. Therefore, check here and do a different telemetry call with the LOC string as othere buttons have.
            if (buttonListener == this.onJoinCodeButton) {
                button.addEventListener('action-activate', () => { Telemetry.sendUIMenuAction({ Menu: TelemetryMenuType.PauseMenu, MenuAction: TelemetryMenuActionType.Select, Item: "LOC_PAUSE_MENU_COPY_JOIN_CODE" }); });
            }
            else {
                button.addEventListener('action-activate', () => { Telemetry.sendUIMenuAction({ Menu: TelemetryMenuType.PauseMenu, MenuAction: TelemetryMenuActionType.Select, Item: caption }); });
            }
            button.addEventListener('action-activate', (event) => {
                event.preventDefault();
                event.stopPropagation();
                this.buttonListener = buttonListener; // By using this member var to route the callback, the member var sets the scope. 
                this.buttonListener(event);
            });
        }
        if (target) {
            target.appendChild(button);
        }
        else {
            console.error(`No target element found for button: ${caption}`);
        }
        this.buttons.add(button);
        return button;
    }
    syncronizeButtonWidths() {
        if (this.Root.isConnected) {
            let maxWidth = 350;
            for (let button of this.buttons) {
                const { width } = button.getBoundingClientRect();
                maxWidth = Math.max(maxWidth, width);
            }
            for (let button of this.buttons) {
                button.style.widthPX = maxWidth;
            }
        }
    }
    onSocialButton() {
        NetworkUtilities.openSocialPanel();
    }
    onOptionsButton() {
        ContextManager.push("screen-options", { singleton: true, createMouseGuard: true });
    }
    onEventRules() {
        ContextManager.push("screen-pause-event-rules", { singleton: true, createMouseGuard: true });
    }
    onChallenges() {
        ContextManager.push("screen-profile-page", { singleton: true, createMouseGuard: true, panelOptions: { onlyChallenges: true, onlyLeaderboards: false } });
    }
    onNoMoreTurnsButton() {
        this.close();
    }
    onRetireButton() {
        DialogManager.createDialog_ConfirmCancel({
            dialogId: this.dialogId,
            body: "LOC_PAUSE_MENU_CONFIRM_RETIRE",
            title: "LOC_PAUSE_MENU_RETIRE",
            callback: (eAction) => { if (eAction == DialogBoxAction.Confirm) {
                this.retireFromGame();
            } }
        });
    }
    onExitToMainMenuButton() {
        DialogManager.createDialog_ConfirmCancel({
            dialogId: this.dialogId,
            body: "LOC_PAUSE_MENU_CONFIRM_QUIT_TO_MENU",
            title: "LOC_PAUSE_MENU_QUIT_TO_MENU",
            callback: (eAction) => { if (eAction == DialogBoxAction.Confirm) {
                this.exitToMainMenu();
            } }
        });
    }
    onQuickSaveGameButton() {
        this.close();
        SaveLoadData.handleQuickSave();
    }
    onSaveGameButton() {
        const configSaveType = GameStateStorage.getGameConfigurationSaveType();
        const configServerType = Network.getServerType();
        ContextManager.push("screen-save-load", { singleton: true, createMouseGuard: true, attributes: { "menu-type": "save", "server-type": configServerType, "save-type": configSaveType } });
    }
    onLoadGameButton() {
        const configSaveType = GameStateStorage.getGameConfigurationSaveType();
        const configServerType = Network.getServerType();
        ContextManager.push("screen-save-load", { singleton: true, createMouseGuard: true, attributes: { "menu-type": "load", "server-type": configServerType, "save-type": configSaveType } });
    }
    retireFromGame() {
        GameContext.sendRetireRequest();
        this.close();
        //! TEMPORARY - The game really should be paused from within GameCore and not reactively by the UI.
        //! This kludge will either become part of the end-game sequence OR be removed when properly handled in GameCore.
        GameContext.sendPauseRequest(true);
    }
    exitToMainMenu() {
        if (Network.supportsSSO() && Online.LiveEvent.getLiveEventGameFlag()) {
            Online.LiveEvent.clearLiveEventGameFlag();
            Online.LiveEvent.clearLiveEventConfigKeys();
        }
        engine.call('exitToMainMenu');
    }
    onExitToDesktopButton() {
        DialogManager.createDialog_ConfirmCancel({
            body: "LOC_PAUSE_MENU_CONFIRM_QUIT_TO_DESKTOP",
            title: "LOC_PAUSE_MENU_QUIT_TO_DESKTOP",
            callback: (eAction) => { if (eAction == DialogBoxAction.Confirm) {
                this.exitToDesktop();
            } }
        });
    }
    exitToDesktop() {
        engine.call('exitToDesktop');
    }
    realizeBuildInfoString() {
        // Update the current version.
        const v = document.querySelector('.build-info');
        if (v) {
            v.innerHTML = Locale.compose('LOC_PAUSE_MENU_BUILD_INFO', BuildInfo.version.display);
        }
        else {
            console.error("screen-pause-menu: realizeBuildInfoString(): Missing v with '.build-info'");
        }
    }
    /// Copies the current join code to the clipboard
    async onJoinCodeButton() {
        UI.setClipboardText(Network.getJoinCode());
    }
    onToggleShowMoreOptions() {
        const added = this.Root.classList.toggle('show-more');
        if (this.showMoreElement) {
            const caption = (added) ? 'LOC_PAUSE_MENU_SHOW_LESS' : 'LOC_PAUSE_MENU_SHOW_MORE';
            this.showMoreElement.setAttribute('caption', caption);
        }
    }
}
const ScreenPauseMenuTagName = 'screen-pause-menu';
Controls.define(ScreenPauseMenuTagName, {
    createInstance: ScreenPauseMenu,
    description: 'Confirm decision to exit main menu.',
    classNames: ['pause-menu'],
    styles: ['fs://game/base-standard/ui/pause-menu/screen-pause-menu.css'],
    content: ['fs://game/base-standard/ui/pause-menu/screen-pause-menu.html']
});

//# sourceMappingURL=file:///base-standard/ui/pause-menu/screen-pause-menu.js.map
