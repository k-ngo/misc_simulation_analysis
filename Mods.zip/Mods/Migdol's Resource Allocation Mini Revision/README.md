# Migdol's Resource Allocation Mini Revision

An interim, quality-of-life improvement to the Resource Allocation screen while we wait for Firaxis to make further improvements.

Thanks to Sukritact's Simple UI Adjustments mod for being an example I could build off.

## Features
* Sorting for resources and settlements
* Simpler scrolling pane for resources

## Installation Instructions
1. You can download the latest stable release at Civfanatic.
2. Extract to the corresponding mods folder
    * Windows: `%localappdata%\Firaxis Games\Sid Meier's Civilization VII\Mods`
    * MacOS: `~/Library/Application Support/Civilization VII/Mods`
    * Steam Deck\Linux: `~/My Games/Sid Meier's Civilization VII/Mods/`
