import { enhancedDiploBannersSettings } from 'fs://game/enhanced-diplomacy-banners/ui/settings/settings.js';

// Export the Zhekoff settings to the global scope
window.Zhekoff_Settings = {
    RelationshipIcons: enhancedDiploBannersSettings
};
